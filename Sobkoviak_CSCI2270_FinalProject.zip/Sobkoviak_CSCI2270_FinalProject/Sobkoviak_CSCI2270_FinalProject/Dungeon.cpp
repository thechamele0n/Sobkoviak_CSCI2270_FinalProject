#include "Dungeon.h"
#include <iostream>

using namespace std;

struct player_character {
    //string name;
    int playerClass;/*warrior, wizard, rogue, bard*/
    string power1;/*swing axe, cast spell, sneaky stab, sing a song*/
    string power2;/*drink a magic potion*/
    string power3;/*charge forwards, hover in the air, use trickery, dance with intense fervor*/
    string power4;/*throw money on the ground*/
    bool hax;
    //int dmg;
    //int health;
};

struct theBoss {
    string bossName;
    int bossHealth;
    int bossDmg;
    string powerOne;
    string powerTwo;
};

struct room {
    string roomName;
    string roomText;
    bool lastRoom;
    bool firstRoom;
    string roomSolutionWar;
    string roomSolutionWiz;
    string roomSolutionRog;
    string roomSolutionBar;
    string successText;
    string successTextPart1; //only for start room, not sure how else to do it to have it print the class you choose
    string successTextPart2;
    string deathText;
    room *child1;
    room *child2;
    room *child3;
};

 room *startRoom = new room;
 player_character *player = new player_character;
 room *currentRoom = new room;


void Dungeon::buildDungeon() {
    //room *startRoom = new room;
    startRoom->roomName = "The Very First Room Through Which Ye Shall Pass";
    startRoom->roomText = "***You hear a voice somewhere speak from somewhere in your mind***... "
    "You have now entered the mysterious Tunnels of Treasure, in which there is hidden "
    "a spectular treasure.  I am the Great Sorcerer and I shall be your everpresent guide on this journey. "
    "Do ye wish to be a warrior? Or perhaps ye prefer to be a wizard? Maybe a rogue? A bard?";
    startRoom->lastRoom = false;
    startRoom->firstRoom = true;
    startRoom->roomSolutionWar = "warrior";
    startRoom->roomSolutionWiz = "wizard";
    startRoom->roomSolutionRog = "rogue";
    startRoom->roomSolutionBar = "bard";
    startRoom->successTextPart1 = "Ah so you have chosen the ";
    startRoom->successTextPart2 = " class. A very astute choice. Let us begin your journey.";
    startRoom->deathText = "Your inability to do something as simple as decide on a class has taken preventative measures "
    "and caused you to drop dead instead of being killed in a much less graceful manner in the next room.";
    room *goblins = new room;
    startRoom->child1 = goblins;
        goblins->roomName = "The Room in Which Grotesque Goblins Reside";
        goblins->roomText = "As you enter, a gaggle of goblins drops from the ceiling and quickly surrounds you, jabbering "
        "in some nonsensical language. They begin to close in on you. It's apparent that you have mere moments before you are torn apart. "
        "What will you do?";
        goblins->lastRoom = false;
        goblins->firstRoom = false;
        goblins->roomSolutionWar = "swing axe";
        goblins->roomSolutionWiz = "cast spell";
        goblins->roomSolutionRog = "sneaky stab";
        goblins->roomSolutionBar = "sing a song";
        goblins->successText = "Your mastery of combat has thwarted and defeated the goblins and they now lay strewn across the floor. You progress down the corridor.";
        goblins->deathText = "You didn't act quick enough. It's quite unfortunate but the goblins have torn you limb from limb.";
        room *theBridge = new room;
        goblins->child1 = theBridge;
        goblins->child2 = theBridge;
        goblins->child3 = theBridge;
    room *snakes = new room;
    startRoom->child2 = snakes;
       snakes->roomName = "The Room Slathered in Slithering Snakes";
       snakes->roomText = "You have entered into room coated in cobras. Act carefully. Their bite is assuredly deadly. What will you do?";
       snakes->lastRoom = false;
       snakes->firstRoom = false;
       snakes->roomSolutionWar = "charge forwards";
       snakes->roomSolutionWiz = "hover in the air";
       snakes->roomSolutionRog = "use trickery";
       snakes->roomSolutionBar = "sing a song";
       snakes->successText = "You have successfully outmaneuvered the snakes without much more than a mere flesh wound.";
       snakes->deathText = "That was probably a dumb move. The snakes are alerted to your presence and effortlessly dispatch you in a series of swift strikes.";
       snakes->child1 = theBridge;
       snakes->child2 = theBridge;
       snakes->child3 = theBridge;
    room *theMinotaur = new room;
    startRoom->child3 = theMinotaur;
        theMinotaur->roomName = "The Room in Which You Will Most Likely Perish at the Hands of an Angry Man-Cow Creature.";
        theMinotaur->roomText = "As you enter the room, you hear loud metal music emanating from within. Your eyes "
        "adjust to the light and you see that there is an incredibly large minotaur in front of you. He seems totally consumed "
        "in the music he's playing on his guitar. What will you do?";
        theMinotaur->lastRoom = false;
        theMinotaur->firstRoom = false;
        theMinotaur->roomSolutionWar = "throw money on the ground";
        theMinotaur->roomSolutionWiz = "throw money on the ground";
        theMinotaur->roomSolutionRog = "throw money on the ground";
        theMinotaur->roomSolutionBar = "sing a song";
        theMinotaur->successText = "The Minotaur accepts your generous tip as a thank you for his performance. He collects the money of the ground and steps "
        "aside so you can continue on your way.";
        theMinotaur->deathText = "You seem to have interupted it. With one mighty swing of his musical axe you are cleaved in two. A shame really.";
        theMinotaur->child1 = theBridge;
        theMinotaur->child2 = theBridge;
        theMinotaur->child3 = theBridge;
    theBridge->roomName = "The Room with a Bridge and a Thinly Veiled Reference to Marty Boa's Floating Carnival";
    theBridge->roomText = "You pass into a massive cavern dominated by a fragile bridge spanning an apparently "
    "bottomless gorge. At the start of the bridge, staring right at you, is a hunched over troll. You approach him "
    "and he immediately begins asking odd questions. You answer the first few with ease but he then asks, 'How many bones are in a giraffe's neck?' "
    "What is your answer? (enter the written name of the number ex. seven)";
    theBridge->lastRoom = false;
    theBridge->firstRoom = false;
    theBridge->roomSolutionWar = "seven";
    theBridge->roomSolutionWiz = "seven";
    theBridge->roomSolutionRog = "seven";
    theBridge->roomSolutionBar = "sing a song";
    theBridge->successText = "You answered correctly and were allowed to cross the bridge. It's actually quite impressive that "
    "you were able to recall that bit of trivia without any help whatsoever. You truly deserve every ounce of your success.";
    theBridge->deathText = "An invisible force launches you screaming out over the gorge to your demise. At least you didn't cheat right?";
    room *theGorgon = new room;
    theBridge->child1 = theGorgon;
        theGorgon->roomName = "The Room With a Gorgon and Not much Else in it. Is that not enough? She tries quite hard to be frightening for your information";
        theGorgon->roomText = "This room, as you have hopefully observed, contains a gorgon. As much as it would be the respectful thing to do, it would do you well not to make eye contact. "
        "Knowing this, you avert your gaze and try to make your way around her. At this, she blocks you off with her tail and begins yelling "
        "profanities at you for not taking the effort to see how scary she is. She puts in a lot of effort to maintain such a "
        "terrifying visage you know. What will you do?";
        theGorgon->lastRoom = false;
        theGorgon->firstRoom = false;
        theGorgon->roomSolutionWar = "swing axe";
        theGorgon->roomSolutionWiz = "hover in the air";
        theGorgon->roomSolutionRog = "sneaky stab";
        theGorgon->roomSolutionBar = "sing a song";
        theGorgon->successText = "Hurt and shocked by your total lack of respect, the Gorgon skulks away and you take this opportunity "
        "to progress onwards unabaited";
        theGorgon->deathText = "As much as you don't want to, you begin to feel immensely guilty for not admiring her "
        "so you decide to briefly glance up. That's it. You don't get any more details. Why am I even still talking? "
        "You're made of stone now. You can't hear me. What a waste of breath.";
        room *Joshua = new room;
        theGorgon->child1 = Joshua;
        theGorgon->child2 = Joshua;
        theGorgon->child3 = Joshua;
    room *plants = new room;
    theBridge->child2 = plants;
        plants->roomName = "The Room Infested with a Variety of Vines and Potentially Carnivorous Plants";
        plants->roomText = "You've stepped into a room that more closely resembles a jungle than a generic dungeon in some half-baked "
        "text-based RPG. You step cautiously across the threshold but without any warning, vines entangle your legs "
        "and dangle you high above the open tooth-lined maw of plant. 'FEED ME SEYMORE' it yells. Confused, you begin to wonder who Seymore is. This genuinely disappoints "
        "me. I was hoping you'd be more concerned with the talking plant that was clearly the imminent danger. It seems I've been wasting time. "
        "You are now falling into this plant's mouth and must act quick. What will you do?";
        plants->lastRoom = false;
        plants->firstRoom = false;
        plants->roomSolutionWar = "drink a magic potion";
        plants->roomSolutionWiz = "drink a magic potion";
        plants->roomSolutionRog = "drink a magic potion";
        plants->roomSolutionBar = "sing a song";
        plants->successText = "Poof! You have temporarily turned into a sentient gaseous cloud. You float away from the confused "
        "plant and out the exit before spontaneously returning to your original form.";
        plants->deathText = "You clearly made a concerted effort but it was in vain. You fell into the mouth of the plant "
        "and were subsequently chewed up into small pieces.";
        plants->child1 = Joshua;
        plants->child2 = Joshua;
        plants->child3 = Joshua;
    room *water = new room;
    theBridge->child3 = water;
        water->roomName = "The Room that is Inexplicably Filled with Water that Doesn't Leak Out into the Corridor";
        water->roomText = "You have just entered a volume of water that fills and seems entirely suspended within the room. "
        "Try as you might, swimming seems to get you nowhere. You are minutes away from drowning. What will you do?";
        water->lastRoom = false;
        water->firstRoom = false;
        water->roomSolutionWar = "drink a magic potion";
        water->roomSolutionWiz = "drink a magic potion";
        water->roomSolutionRog = "drink a magic potion";
        water->roomSolutionBar = "sing a song";
        water->successText = "You slowly, and probably quite painfully, morph into a fish and manage to swim across to the "
        "other side of the room.";
        water->deathText = "Your efforts are in vain. You drowned. And I bet you thought you'd die an exciting death that was worthy of "
        "an adventurer such as yourself.";
        water->child1 = Joshua;
        water->child2 = Joshua;
        water->child3 = Joshua;
    Joshua->roomName = "A Small Room";
    Joshua->roomText = "You have entered a relatively small room. In this room, there sits a man at a desk. On this desk appears to be a board game of some sort. "
    "It is titled 'Global Thermonuclear War'. The man asks you one question. 'Do you want to play a game?'(enter play or don't play)";
    Joshua->lastRoom = true;
    Joshua->firstRoom = false;
    Joshua->roomSolutionWar = "don't play";
    Joshua->roomSolutionWiz = "don't play";
    Joshua->roomSolutionRog = "don't play";
    Joshua->roomSolutionBar = "sing a song";
    Joshua->successText = "You have correctly deduced that the only winning move is not to play. Joshua accepts this and allows you to procede to your final challenge.";
    Joshua->deathText = "You may be smart, but you are no match for Joshua. You are swiftly beaten and before you even have time to comprehend the situation, you and the rest of the tunnels and its contents are annihilated in "
    "a cataclysmic scale explosion.";
    Joshua->child1 = NULL;
    Joshua->child2 = NULL;
    Joshua->child3 = NULL;
}

void Dungeon::displayOptions(){
    cout<<"---------------------------------"<<endl;
    cout<<player->power1<<endl;
    cout<<player->power2<<endl;
    cout<<player->power3<<endl;
    cout<<player->power4<<endl;
    cout<<"---------------------------------"<<endl;
    cout<<currentRoom->roomText<<endl;
}

void Dungeon::receiveTreasure() {
    cout<<"You have successfully navigated the Tunnels of Treasure and you now will receive your treasure. "
        "You open the treasure chest to discover that you've been awarded with a dead Norwegian Blue Parrot. Beautiful plumage eh?"<<endl;
}

void Dungeon::assignWarrior(){
    player->playerClass = 1;
    player->power1 = "swing axe";
    player->power2 = "drink a magic potion";
    player->power3 = "charge forwards";
    player->power4 = "throw money on the ground";
    player->hax = false;
}

void Dungeon::assignWizard(){
    player->playerClass = 2;
    player->power1 = "cast a spell";
    player->power2 = "drink a magic potion";
    player->power3 = "hover in the air";
    player->power4 = "throw money on the ground";
    player->hax = false;
}

void Dungeon::assignRogue(){
    player->playerClass = 3;
    player->power1 = "sneaky stab";
    player->power2 = "drink a magic potion";
    player->power3 = "use trickery";
    player->power4 = "throw money on the ground";
    player->hax = false;
}

void Dungeon::assignBard(){
    player->playerClass = 4;
    player->power1 = "sing a song";
    player->power2 = "drink a magic potion";
    player->power3 = "dance with intense fervor";
    player->power4 = "throw money on the ground";
    player->hax = true;
}

void Dungeon::playAdventure() {
    currentRoom = startRoom;
    bool dead = false;
    bool isWin = false;
    while(currentRoom != NULL){
        cout<<"You have entered "<<currentRoom->roomName<<endl;
        cout<<currentRoom->roomText<<endl;
        string choice;
        getline(cin, choice);
        if(currentRoom->firstRoom == true){
            //player_character *player = new player_character;
            if(choice == "warrior"){
                assignWarrior();
                cout<<currentRoom->successTextPart1<<"warrior"<<currentRoom->successTextPart2<<endl;
                cout<<"---------------------------------"<<endl;
                currentRoom = currentRoom->child3;
            }
            else if(choice == "wizard"){
                assignWizard();
                cout<<currentRoom->successTextPart1<<"wizard"<<currentRoom->successTextPart2<<endl;
                cout<<"---------------------------------"<<endl;
                currentRoom = currentRoom->child2;
            }
            else if(choice == "rogue"){
                assignRogue();
                cout<<currentRoom->successTextPart1<<"rogue"<<currentRoom->successTextPart2<<endl;
                cout<<"---------------------------------"<<endl;
                currentRoom = currentRoom->child1;
            }
            else if(choice == "bard"){
                assignBard();
                cout<<currentRoom->successTextPart1<<"bard"<<currentRoom->successTextPart2<<endl;
                cout<<"---------------------------------"<<endl;
                currentRoom = currentRoom->child1;
            }
            else{
                cout<<currentRoom->deathText<<endl;
                dead = true;
                currentRoom = NULL;
            }
        }
        else{
            if(player->playerClass == 1){
                if(choice == "options"){
                    displayOptions();
                    getline(cin, choice);
                    if(choice == currentRoom->roomSolutionWar){
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->successText<<endl;
                        cout<<"---------------------------------"<<endl;
                        if(currentRoom->lastRoom == true){
                            isWin = true;
                        }
                        currentRoom = currentRoom->child3;
                    }
                    else{
                        cout<<currentRoom->deathText<<endl;
                        dead = true;
                        currentRoom = NULL;
                    }
                }
                else if(choice == currentRoom->roomSolutionWar){
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->successText<<endl;
                    cout<<"---------------------------------"<<endl;
                    if(currentRoom->lastRoom == true){
                        isWin = true;
                    }
                    currentRoom = currentRoom->child3;
                }
                else{
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->deathText<<endl;
                    dead = true;
                    currentRoom = NULL;
                }

            }
            if(player->playerClass == 2){
                if(choice == "options"){
                    displayOptions();
                    getline(cin, choice);
                    if(choice == currentRoom->roomSolutionWiz){
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->successText<<endl;
                        cout<<"---------------------------------"<<endl;
                        if(currentRoom->lastRoom == true){
                            isWin = true;
                        }
                        currentRoom = currentRoom->child2;
                    }
                    else{
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->deathText<<endl;
                        dead = true;
                        currentRoom = NULL;
                    }
                }
                else if(choice == currentRoom->roomSolutionWiz){
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->successText<<endl;
                    cout<<"---------------------------------"<<endl;
                    if(currentRoom->lastRoom == true){
                            isWin = true;
                    }
                    currentRoom = currentRoom->child2;
                }
                else{
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->deathText<<endl;
                    dead = true;
                    currentRoom = NULL;
                }
            }
            if(player->playerClass == 3){
                if(choice == "options"){
                    displayOptions();
                    getline(cin, choice);
                    if(choice == currentRoom->roomSolutionRog){
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->successText<<endl;
                        cout<<"---------------------------------"<<endl;
                        if(currentRoom->lastRoom == true){
                            isWin = true;
                        }
                        currentRoom = currentRoom->child1;
                    }
                    else{
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->deathText<<endl;
                        dead = true;
                        currentRoom = NULL;
                    }
                }
                else if(choice == currentRoom->roomSolutionRog){
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->successText<<endl;
                    cout<<"---------------------------------"<<endl;
                    if(currentRoom->lastRoom == true){
                        isWin = true;
                    }
                    currentRoom = currentRoom->child1;
                }
                else{
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->deathText<<endl;
                    dead = true;
                    currentRoom = NULL;
                }
            }
            if(player->playerClass == 4){
                if(choice == "options"){
                    displayOptions();
                    getline(cin, choice);
                    if(choice == currentRoom->roomSolutionBar){
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->successText<<endl;
                        cout<<"---------------------------------"<<endl;
                        if(currentRoom->lastRoom == true){
                            isWin = true;
                        }
                        currentRoom = currentRoom->child2;
                    }
                    else{
                        cout<<"---------------------------------"<<endl;
                        cout<<currentRoom->deathText<<endl;
                        dead = true;
                        currentRoom = NULL;
                    }
                }
                else if(choice == currentRoom->roomSolutionBar){
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->successText<<endl;
                    cout<<"---------------------------------"<<endl;
                    if(currentRoom->lastRoom == true){
                        isWin = true;
                    }
                    currentRoom = currentRoom->child2;
                }
                else{
                    cout<<"---------------------------------"<<endl;
                    cout<<currentRoom->deathText<<endl;
                    dead = true;
                    currentRoom = NULL;
                }
            }
        }
        
        string playAgain;

        if(dead == false && isWin == true){
            receiveTreasure();
            cout<<"Would you like to play again?"<<endl;
            getline(cin, playAgain);
            while(playAgain != "no"){
                if(playAgain == "yes"){
                    currentRoom = startRoom;
                    playAgain = "no";
                }else{
                    cout<<"Invalid input"<<endl;
                }
            }
        }else if(dead == true){
            cout<<"Would you like to play again?"<<endl;
            getline(cin, playAgain);
            while(playAgain != "no"){
                if(playAgain == "yes"){
                    currentRoom = startRoom;
                    dead = false;
                    playAgain = "no";
                }else{
                    cout<<"Invalid input"<<endl;
                }
            }
        }
    }
    //if(dead == false){
    //    receiveTreasure();
    //}
}

Dungeon::Dungeon()
{
    //ctor
}

Dungeon::~Dungeon()
{
    //dtor
}
