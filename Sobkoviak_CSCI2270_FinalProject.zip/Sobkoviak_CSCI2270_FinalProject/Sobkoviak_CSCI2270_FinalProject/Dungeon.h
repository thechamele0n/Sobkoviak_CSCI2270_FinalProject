#ifndef DUNGEON_H
#define DUNGEON_H


class Dungeon
{
    public:
        void assignWarrior();
        void assignWizard();
        void assignRogue();
        void assignBard();
        void displayOptions();
        void receiveTreasure();
        void buildDungeon();
        void playAdventure();
        Dungeon();
        ~Dungeon();
    protected:
    private:
};

#endif // DUNGEON_H
