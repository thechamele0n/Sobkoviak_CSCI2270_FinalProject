#include <iostream>
#include "Dungeon.h"

using namespace std;

int main()
{
    Dungeon theTunnels;
    theTunnels.buildDungeon();
    theTunnels.playAdventure();
    return 0;
}
